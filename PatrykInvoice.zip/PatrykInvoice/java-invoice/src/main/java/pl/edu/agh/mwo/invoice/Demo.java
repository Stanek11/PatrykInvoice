package pl.edu.agh.mwo.invoice;

public class Demo {
    public static void main(String[] args) {
        System.out.println(0.1 + 0.2);
    }
}
